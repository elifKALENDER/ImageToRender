IMAGETORENDER RESTORATION — WORKFLOW KOD PAKETİ
Tarih: 2026-08-24

Bu paket, şu ana kadar workflow'da kabul edilerek ilerlediğimiz son kodları
tek ve temiz bir sırada toplar. Eski denemeler özellikle dahil edilmemiştir.

AKTİF / KABUL EDİLMİŞ AKIŞ
01  Stage 1 — multiscale detection
02  Stage 2C — DINOv2 repetition
03  Stage 2D — cleaned axes
04  Stage 2F — raw candidate fusion
05  Stage 3A — existing evidence skeleton
06  Stage 3B-v2 — perspective families
07  Stage 3B-v3 — family cleanup
08  Stage 3B-v4 — observed instance recovery
09  Stage 3B-v5b — expert inventory editor
10  Stage 3C-A — architectural relations
11  Stage 3C-B — facade sectors and bays
12  Stage 3C-C — reconstruction hypotheses expert editor
13  Stage 4 — geometric reconstruction

STAGE 5
Stage 5 AI inpaint V1 çalıştırıldı ancak çıktı başarısız bulundu. Bu yüzden
aktif workflow'a eklenmedi. 05_STAGE5/STAGE5_STATUS.txt içinde durum kayıtlı.
Stage 5 V2 bundan sonra yeniden tasarlanacak.

ÖNEMLİ
Bu zip "bütün eski py dosyaları" arşivi değildir. Amaç, yeni bir görselle
pipeline'ı hangi dosyalarla sırayla çalıştıracağımızı karıştırmadan saklamaktır.
Eski deney/audit arşivleri ayrı tutulmuştur.
