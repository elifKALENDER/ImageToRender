BU ZIP NE İÇERİYOR?
====================
Bu paket, bu sohbette birlikte ilerlediğimiz workflow içinde adı geçen ve /mnt/data altında exact olarak erişilebilen Python dosyalarını ÖZGÜN ADLARIYLA içerir.

ÖNEMLİ:
- Dosya adları değiştirilmemiştir.
- Paket içine yeni stage adı verilmiş kopyalar eklenmemiştir.
- completion_mask çizim ekranı ayrı bir py olarak çıkarılmadı; bunun için ImageToRender2Restoration_v5.py içindeki create_mask_with_editor(...) kullanılır.
- Bu paket yalnız erişilebilen exact .py dosyaları içerir.

ÖNERİLEN OKUMA / ÇALIŞTIRMA SIRASI
----------------------------------
1) ImageToRender2Restoration_v5.py
   -> completion_mask.png çizmek için (manuel maske editörü)
2) ImageToRender2Restoration_v8_stage1_multiscale.py
3) ImageToRender2Restoration_v8_stage2_dinov2_repetition.py
4) ImageToRender2Restoration_v8_stage2f_raw_candidate_fusion.py
5) ImageToRender2Restoration_v8_stage3a_existing_evidence_skeleton.py
6) ImageToRender2Restoration_v8_stage3b_element_families.py
7) ImageToRender2Restoration_v8_stage3b_v3_family_cleanup.py
8) ImageToRender2Restoration_v8_stage3b_v4_observed_instance_recovery.py
9) ImageToRender2Restoration_v8_stage3b_v5_expert_inventory_editor.py
   veya yeni denemelerde ImageToRender2Restoration_v8_stage3b_v5b_clean_expert_inventory_editor.py
10) ImageToRender2Restoration_v8_stage3c_a_architectural_relations.py
11) ImageToRender2Restoration_v8_stage3c_b_facade_sectors_and_bays.py

NOTLAR
------
- Bu paket özellikle senin istediğin gibi "hangi py dosyaları var" sorusuna net cevap vermek için hazırlandı.
- stage3c_b dosyası pakette var ama onaylı final aşama olarak değil, sonraki aşama adayı olarak düşünülmeli.
